import os
from flask import Flask,render_template,url_for,flash,redirect,request
from forms import RegistrationForm,LoginForm
from werkzeug.utils import secure_filename
from database import Datasave,Dataread

UPLOAD_FOLDER = '/Users/Anubhav/Flask_Mendel/uploads/'
ALLOWED_EXTENSIONS = set(['txt','csv'])

app = Flask(__name__)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['SECRET_KEY']='5775df32c0f6472dae977b0c5625e030'


def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route("/")
@app.route("/home")
def home():
    return render_template('home.html')

@app.route("/targetdefinition")
def targetdefinition():
    return render_template('targetdefinition.html',title='Target definition')

@app.route("/datainput",methods=['GET', 'POST'])
def upload_file():
    df=Dataread()
    if request.method == 'POST':
        # check if the post request has the file part
        if 'file' not in request.files:
            flash('NO file Part!', 'danger')
            return redirect(request.url)
        file = request.files['file']
        # if user does not select file, browser also
        # submit a empty part without filename
        if file.filename == '':
            flash('No selected file', 'danger')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(os.getcwd(),app.config['UPLOAD_FOLDER'], filename))
            Datasave(os.path.join(os.getcwd(),app.config['UPLOAD_FOLDER'], filename))
            flash('File Upload Successfull!', 'success')
            return redirect(url_for('home'))
    return render_template('datainput.html',title='Data Input',tables=[df.to_html(classes='data')], titles=df.columns.values)

@app.route("/actionplan")
def actionplan():
    return render_template('actionplan.html',title='Action Plan')

@app.route("/targetranking")
def targetranking():
    return render_template('targetranking.html',title='Target Ranking')

@app.route("/accountanalysis")
def accountanalysis():
    return render_template('accountanalysis.html',title='Account Analysis')

@app.route("/territoryanalysis")
def territoryanalysis():
    return render_template('territoryanalysis.html',title='Territory Analysis')

@app.route("/about")
def about():
    return render_template('about.html',title='About')

@app.route("/register",methods=['GET','POST'])
def register():
    form=RegistrationForm()
    if form.validate_on_submit():
        flash(f'Account created for {form.username.data}!','success')
        return redirect(url_for('home'))
    return render_template('register.html',title='Register',form=form)

@app.route("/login", methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        if form.email.data == 'admin@blog.com' and form.password.data == 'password':
            flash('You have been logged in!', 'success')
            return redirect(url_for('home'))
        else:
            flash('Login Unsuccessful. Please check username and password', 'danger')
    return render_template('login.html', title='Login', form=form)
 
if __name__=='__main__':
    app.run(debug=True)
