# -*- coding: utf-8 -*-
"""
Created on Fri Apr  5 13:49:53 2019

@author: 555224
"""


import sqlite3
import pandas as pd

data=pd.read_csv('Book4.csv')

data.columns


for index, row in data.iterrows():
    print(row['player_id'], row['Player'])
    


conn = sqlite3.connect('example2.db')

c = conn.cursor()

# Save (commit) the changes
conn.commit()

#c.execute('''CREATE TABLE try
 #            (player_id real, Player text, ROLE text, BATTING_STYLE text, BOWLING_STYLE text,NATIONALITY text)''')

    
#for index, row in data.iterrows():
#    c.execute('INSERT INTO try VALUES (?,?,?,?,?,?)',row)

conn.commit() 

for row in c.execute('SELECT * FROM try'):
        print(row)
        
conn.close()