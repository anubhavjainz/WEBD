import os
from flask import Flask,render_template,url_for,flash,redirect,request
from flask_sqlalchemy import SQLAlchemy
from forms import RegistrationForm,LoginForm
from werkzeug.utils import secure_filename
from database import Datasave,Dataread,DatasaveLine

UPLOAD_FOLDER = '/Mendel_Shoaib/'
ALLOWED_EXTENSIONS = set(['txt','csv'])

app = Flask(__name__)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['SECRET_KEY']='5775df32c0f6472dae977b0c5625e030'


def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
           
@app.route("/")
@app.route("/home")
def home():
    return render_template('home.html')

@app.route("/targetdefinition",methods=['GET', 'POST'])
def targetdefinition():
    if request.method == 'POST':
        # check if the post request has the file part
        if 'file' not in request.files:
            flash('No file Part!', 'danger')
            return redirect(request.url)
        file = request.files['file']
        # if user does not select file, browser also
        # submit a empty part without filename
        if file.filename == '':
            flash('No selected file', 'danger')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(os.getcwd(),app.config['UPLOAD_FOLDER'], filename))
            Datasave(os.path.join(os.getcwd(),app.config['UPLOAD_FOLDER'], filename))
            flash('File Upload Successfull!', 'success')
            return redirect(url_for('targetdefinition'))  
    return render_template('targetdefinition.html',title='Target definition')

@app.route("/datainput", methods=['GET', 'POST'])
def datainput():
    df=Dataread()
    if request.method == 'POST':
       Health_Groups = request.form.get('Health_Groups')
       Account_ID = request.form.get('Account_ID')
       Account_Name = request.form.get('Account_Name')
       Account_Relationship = request.form.get('Account_Relationship')
       Injection_Potential = request.form.get('Injection_Potential')
       Product_Adoption = request.form.get('Product_Adoption')
       Competitve_Situation = request.form.get('Competitve_Situation')
       Clinical_Mindset = request.form.get('Clinical_Mindset')
       Value_Perception = request.form.get('Value_Perception')
       my_list = [Health_Groups, Account_ID, Account_Name,Account_Relationship,Injection_Potential,Product_Adoption,Competitve_Situation,Clinical_Mindset,Value_Perception]
       DatasaveLine(my_list)
       flash('Record Added Successfully!', 'success')
       return redirect(url_for('datainput')) 
    return render_template('datainput.html',title='Data Input',tables=[df.to_html(classes='data')], titles=df.columns.values)

@app.route("/actionplan")
def actionplan():
    return render_template('actionplan.html',title='Action Plan')

@app.route("/targetranking")
def targetranking():
    return render_template('targetranking.html',title='Target Ranking')

@app.route("/accountanalysis")
def accountanalysis():
    return render_template('accountanalysis.html',title='Account Analysis')

@app.route("/territoryanalysis")
def territoryanalysis():
    return render_template('territoryanalysis.html',title='Territory Analysis')

@app.route("/about")
def about():
    return render_template('about.html',title='About')

@app.route("/login", methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        if form.email.data == 'admin@email.com' and form.password.data == 'admin':
            flash('You have been logged in!', 'success')
            return redirect(url_for('targetdefinition'))
        else:
            flash('Login Unsuccessful. Please check username and password', 'danger')
    return render_template('login.html', title='Login', form=form)

if __name__=='__main__':
    app.run(debug=True)
