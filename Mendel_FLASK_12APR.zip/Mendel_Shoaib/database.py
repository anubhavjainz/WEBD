# -*- coding: utf-8 -*-
"""
Created on Fri Apr  5 13:49:53 2019

@author: 555224
"""

import sqlite3
import pandas as pd

def Datasave(filepath):
	data=pd.read_csv(filepath)
	conn = sqlite3.connect('mendel_database.db')
	c = conn.cursor()
	for index, row in data.iterrows():
		c.execute('INSERT INTO data_input VALUES (?,?,?,?,?,?,?,?,?)',row)
	conn.commit() 
	conn.close()

def Dataread():
    conn = sqlite3.connect('mendel_database.db')
    c = conn.cursor()
    df = pd.read_sql_query("SELECT * FROM data_input", conn) 
    conn.close()
    return df

def DatasaveLine(mylist):
	conn = sqlite3.connect('mendel_database.db')
	c = conn.cursor()
	c.execute('INSERT INTO data_input VALUES (?,?,?,?,?,?,?,?,?)',mylist)
	conn.commit() 
	conn.close()
